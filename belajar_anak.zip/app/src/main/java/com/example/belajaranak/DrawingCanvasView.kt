package com.example.belajaranak

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.random.Random

class DrawingCanvasView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var targetText: String = "A"
        set(value) {
            field = value
            clearCanvas()
        }

    private val brightColors = intArrayOf(
        Color.parseColor("#FF1744"),
        Color.parseColor("#FF9100"),
        Color.parseColor("#FFEA00"),
        Color.parseColor("#00E676"),
        Color.parseColor("#00B0FF"),
        Color.parseColor("#D500F9")
    )

    private class ColoredPath(val path: Path, val color: Int)
    private val pathList = mutableListOf<ColoredPath>()

    private var currentPath = Path()
    private var currentColor = getRandomColor()

    private val drawPaint = Paint().apply {
        isAntiAlias = true
        isDither = true
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 42f
    }

    private val textGuidePaint = Paint().apply {
        isAntiAlias = true
        color = Color.LTGRAY
        alpha = 90
        style = Paint.Style.FILL
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }

    private fun getRandomColor(): Int {
        return brightColors[Random.nextInt(brightColors.size)]
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (targetText.isNotEmpty()) {
            textGuidePaint.textSize = height * 0.45f
            val xPos = width / 2f
            val yPos = (height / 2f) - ((textGuidePaint.descent() + textGuidePaint.ascent()) / 2f)
            canvas.drawText(targetText, xPos, yPos, textGuidePaint)
        }

        for (coloredPath in pathList) {
            drawPaint.color = coloredPath.color
            canvas.drawPath(coloredPath.path, drawPaint)
        }

        drawPaint.color = currentColor
        canvas.drawPath(currentPath, drawPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                currentColor = getRandomColor()
                currentPath = Path()
                currentPath.moveTo(x, y)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                currentPath.lineTo(x, y)
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                pathList.add(ColoredPath(currentPath, currentColor))
                currentPath = Path()
                invalidate()
            }
            else -> return false
        }
        return true
    }

    fun clearCanvas() {
        pathList.clear()
        currentPath.reset()
        invalidate()
    }
}
