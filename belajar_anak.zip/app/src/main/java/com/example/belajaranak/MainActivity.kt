package com.example.belajaranak

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.ai.client.generativeai.GenerativeModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private var isTtsReady = false

    private lateinit var tvInstruction: TextView
    private lateinit var tvWordExample: TextView
    private lateinit var canvasView: DrawingCanvasView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnNext: Button
    private lateinit var btnClear: Button

    private val GEMINI_API_KEY = "YOUR_GEMINI_API_KEY_HERE"

    private val generativeModel by lazy {
        GenerativeModel(
            modelName = "gemini-1.5-flash",
            apiKey = GEMINI_API_KEY
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tts = TextToSpeech(this, this)

        tvInstruction = findViewById(R.id.tvInstruction)
        tvWordExample = findViewById(R.id.tvWordExample)
        canvasView = findViewById(R.id.drawingCanvas)
        progressBar = findViewById(R.id.progressBar)
        btnNext = findViewById(R.id.btnNext)
        btnClear = findViewById(R.id.btnClear)

        btnClear.setOnClickListener {
            canvasView.clearCanvas()
            speakText("Ayo bersihkan dan coba tulis lagi ya!")
        }

        btnNext.setOnClickListener {
            generateContentFromGemini()
        }

        generateContentFromGemini()
    }

    private fun generateContentFromGemini() {
        if (GEMINI_API_KEY == "YOUR_GEMINI_API_KEY_HERE") {
            val defaultLetters = arrayOf("A", "B", "C", "D", "1", "2", "3")
            val randomChar = defaultLetters.random()
            updateUI(randomChar, "Ayo tebalkan huruf atau angka ini!", "$randomChar untuk Belajar 🌟")
            return
        }

        progressBar.visibility = View.VISIBLE
        btnNext.isEnabled = false

        val prompt = """
            Kamu adalah guru TK yang sangat ceria dan ramah.
            Buatkan 1 materi belajar membaca/menulis untuk anak usia 5 tahun secara acak (bisa huruf A-Z atau angka 1-10).
            Kembalikan HANYA format JSON murni tanpa markdown formatting seperti berikut:
            {
              "target": "A",
              "instruksi": "Halo Adik manis! Yuk tebalkan huruf A besar ini!",
              "contoh_kata": "A untuk Apel! 🍎 Nyum nyum enak!"
            }
        """.trimIndent()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = generativeModel.generateContent(prompt)
                val jsonText = response.text?.replace("```json", "")?.replace("```", "")?.trim() ?: ""
                
                val jsonObject = JSONObject(jsonText)
                val target = jsonObject.getString("target")
                val instruksi = jsonObject.getString("instruksi")
                val contohKata = jsonObject.getString("contoh_kata")

                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    btnNext.isEnabled = true
                    updateUI(target, instruksi, contohKata)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    btnNext.isEnabled = true
                    val fallbackChar = ('A'..'Z').random().toString()
                    updateUI(fallbackChar, "Yuk mari kita tebalkan bersama!", "$fallbackChar untuk Belajar 🌟")
                }
            }
        }
    }

    private fun updateUI(target: String, instruksi: String, contohKata: String) {
        canvasView.targetText = target
        tvInstruction.text = instruksi
        tvWordExample.text = contohKata

        speakText("$instruksi ... $contohKata")
    }

    private fun speakText(text: String) {
        if (isTtsReady) {
            tts.setPitch(1.5f)
            tts.setSpeechRate(0.9f)
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("id", "ID"))
            if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                isTtsReady = true
            }
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
